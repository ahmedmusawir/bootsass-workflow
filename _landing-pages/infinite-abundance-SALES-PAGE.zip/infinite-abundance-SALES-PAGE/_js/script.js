jQuery(document).ready(function($) {

  $( 'body' ).fadeIn(900);	

	new WOW().init();
});